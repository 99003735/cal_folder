#ifndef __MYUTILS_H
#define __MYUTILS_H

int fact(int n);
int checkPalindrome(int number);
int is_Prime(int num);
double vsum(int number,...);

#endif
