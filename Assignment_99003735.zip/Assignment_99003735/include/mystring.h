#ifndef __MYSTRING_H
#define __MYSTRING_H

char* mystrcat(char *str1, char *str2);
int str_Compare(char *str1, char *str2);
char* mystrcpy(char *str1, char *str2);
int mystrlen(char *str);

#endif
