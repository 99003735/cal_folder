#include "mystring.h"

int mystrlen(char *str)
{
    int len=0;
    int i=0;
    while(str[i]!='\0')
    {
       i++;
       len++;
    }
    
    return (len);
}