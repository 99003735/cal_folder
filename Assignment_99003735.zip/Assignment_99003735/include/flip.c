 #include "bitmask.h"
 
 int flip_Number(int input, int output)
 {
     
     output = ~input;
     return output;
 }