#ifndef __BITMASK_H
#define __BITMASK_H

int flip_Number(int input, int output);
int setBit(int n, int k);
int reset(int input, int bit);

#endif
