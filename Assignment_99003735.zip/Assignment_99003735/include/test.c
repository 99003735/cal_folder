#include "mystring.h"
#include "bitmask.h"
#include "myutils.h"
#include <stdio.h>
#include <stdarg.h>

int main()
{
    char str1[30] = "C-Program-Activity";
    char str2[30];
    char str3[30]= "C-Program-Activity";

   
    int n=5;
    int n1=1441;
    int bit =1;
    int output;
    
    printf("Length of a string = %d\n",mystrlen(str1));
    
    printf("First string s1 = %s Second string s2=%s\n",str1,mystrcpy(str1,str2));
    printf("String s1=%s, String s2=%s\n",str1,mystrcat(str1,str2));
    printf("'0' means equal and '1' means not equal\n");

    printf("Compare two strings %d\n",str_Compare(str1,str3));
           
    printf("Factorial of %d = %d\n",n,fact(n));
           
    printf("'0' means composite and '1' means not prime\n");
    printf("%d\n",is_Prime(n));
           
    printf("'0' means palindrome and  '1' means not a palindrome\n");
    printf("%d",checkPalindrome(n1));

    printf("vsum of two numbers = %f\n", vsum(2,10,20));

    printf("set %d=%d\n",n,setBit(n,bit));
    printf("Reset %d=%d\n",n,reset(n,bit));

     printf ("Flip of %d=%d\n",n,flip_Number(n,output)); 
     return 0;   
}
